#pragma once
#include "Jugador.h"
class JugadorPc : public Jugador
{
public:
	void seleccionar();
};

